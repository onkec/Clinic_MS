Clinic Stock Management System in C#,

This project is implemented using C#, and asp.net framework in Visual Studio 2022.
I Have used local visual studio for database.
You will need to download and install visual studio 2022 and make sure you add dot net framework packages.
Should run into any errors kindly let me know at cetywayo.onke@gmail.com.
The System have tested and is working perfectly, as a results All required data have added to the database.