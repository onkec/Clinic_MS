﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;
using Clinic_SMS.Models;

namespace Clinic_SMS.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public virtual DbSet<Clinic_SMS.Models.Clinic> Clinic { get; set; }
        public virtual DbSet<Clinic_SMS.Models.Medication> Medication { get; set; }
        public virtual DbSet<MedicationClinic> MedicationClinic { get; set; }
    }
}
