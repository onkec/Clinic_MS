﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Clinic_SMS.Data;
using Clinic_SMS.Models;

namespace Clinic_SMS.Controllers
{
    public class MedicationClinicsController : Controller
    {
        private readonly ApplicationDbContext _context;

        public MedicationClinicsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: MedicationClinics
        public async Task<IActionResult> Index()
        {
            var applicationDbContext = _context.MedicationClinic.Include(m => m.Clinic).Include(m => m.Medication);
            return View(await applicationDbContext.ToListAsync());
        }

        //GET Low Stock
        public IActionResult LowStockLevel()
        {
            //lowStock=List<>;
            var medication = _context.MedicationClinic.Include(x => x.Medication).Include(x => x.Clinic).Where(x=>x.MedicationLevel<5);
            
            return View( medication);
        }

        // GET: MedicationClinics/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicationClinic = await _context.MedicationClinic
                .Include(m => m.Clinic)
                .Include(m => m.Medication)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (medicationClinic == null)
            {
                return NotFound();
            }

            return View(medicationClinic);
        }

        // GET: MedicationClinics/Create
        public IActionResult Create()
        {
            ViewData["ClinicId"] = new SelectList(_context.Clinic, "Id", "Id");
            ViewData["MedicationId"] = new SelectList(_context.Medication, "Id", "Id");
            return View();
        }

        // POST: MedicationClinics/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,ClinicId,MedicationId,MedicationLevel")] MedicationClinic medicationClinic)
        {
            if (ModelState.IsValid)
            {
                _context.Add(medicationClinic);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClinicId"] = new SelectList(_context.Clinic, "Id", "Id", medicationClinic.ClinicId);
            ViewData["MedicationId"] = new SelectList(_context.Medication, "Id", "Id", medicationClinic.MedicationId);
            return View(medicationClinic);
        }

        // GET: MedicationClinics/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicationClinic = await _context.MedicationClinic.FindAsync(id);
            if (medicationClinic == null)
            {
                return NotFound();
            }
            ViewData["ClinicId"] = new SelectList(_context.Clinic, "Id", "Id", medicationClinic.ClinicId);
            ViewData["MedicationId"] = new SelectList(_context.Medication, "Id", "Id", medicationClinic.MedicationId);
            return View(medicationClinic);
        }

        // POST: MedicationClinics/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for 
        // more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,ClinicId,MedicationId,MedicationLevel")] MedicationClinic medicationClinic)
        {
            if (id != medicationClinic.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(medicationClinic);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MedicationClinicExists(medicationClinic.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["ClinicId"] = new SelectList(_context.Clinic, "Id", "Id", medicationClinic.ClinicId);
            ViewData["MedicationId"] = new SelectList(_context.Medication, "Id", "Id", medicationClinic.MedicationId);
            return View(medicationClinic);
        }

        // GET: MedicationClinics/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var medicationClinic = await _context.MedicationClinic
                .Include(m => m.Clinic)
                .Include(m => m.Medication)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (medicationClinic == null)
            {
                return View("There is no stock to display; Check your database!!");
            }

            return View(medicationClinic);
        }

        // POST: MedicationClinics/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var medicationClinic = await _context.MedicationClinic.FindAsync(id);
            _context.MedicationClinic.Remove(medicationClinic);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MedicationClinicExists(int id)
        {
            return _context.MedicationClinic.Any(e => e.Id == id);
        }
    }
}
