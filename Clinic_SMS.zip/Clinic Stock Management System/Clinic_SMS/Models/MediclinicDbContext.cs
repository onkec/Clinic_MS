﻿using System.Data.Entity;
using System.Collections.Generic;
using System;

namespace Clinic_SMS.Models
{
    public class MediclinicDbContext:DbContext
    {
        public DbSet<Clinic> Clinics { get; set;}
        public DbSet<Medication> Medications { get; set; }
        public DbSet<MedicationClinic> MedicationClinics { get; set; }
    }
}
