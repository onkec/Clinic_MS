﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Clinic_SMS.Models
{
    public class Clinic
    {
        //Clinic properties
        public int Id { get; set; }

        [Display(Name = "Clinic Name")]
        public string ClinicName { get; set; }
        public string Country { get; set; }

        //Many to Many relationship virtual access
        //public virtual ICollection<MedicationClinic> MedicationAndClinics { get; set; }

        //Clinic method or constructor
        //public Clinic()
        //{

        //}
    }
}
