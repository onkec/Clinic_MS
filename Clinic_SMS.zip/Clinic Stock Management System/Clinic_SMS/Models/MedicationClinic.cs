﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Clinic_SMS.Models
{
    public class MedicationClinic
    {
        public int Id { get; set; }
        public int ClinicId { get; set; }
        public int MedicationId { get; set; }

        [Display(Name = "Medication Level")]
        public int MedicationLevel {get; set;}

        public virtual Clinic Clinic { get; set; }
        public virtual Medication Medication { get; set; }
        
    }
}
