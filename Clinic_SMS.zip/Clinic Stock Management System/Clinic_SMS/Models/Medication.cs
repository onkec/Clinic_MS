﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Clinic_SMS.Models
{
    public class Medication
    {
        //Medication properties or methods
        public int Id { get; set; }

        [Display(Name = "Medication Name")]
        public string MedicationName { get; set; }


        //Many to Many relationship virtual access
        //public virtual ICollection<MedicationClinic> MedicationAndClinics { get; set; }


        //Medication constructor
        //public Medication()
        //{

        //}
    }
}
